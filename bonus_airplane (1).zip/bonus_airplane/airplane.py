import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.impute import SimpleImputer
from collections import Counter

# Load data
train_df = pd.read_csv('train.csv')
test_df = pd.read_csv('test.csv')
drop_cols = ['id'] if 'id' in train_df.columns else []
train_df.drop(columns=drop_cols, inplace=True, errors='ignore')
test_df.drop(columns=drop_cols, inplace=True, errors='ignore')

# Combine for preprocessing
full_df = pd.concat([train_df, test_df], axis=0)

numeric_cols = full_df.select_dtypes(include=['int64', 'float64']).columns
num_imputer = SimpleImputer(strategy='mean')
full_df[numeric_cols] = num_imputer.fit_transform(full_df[numeric_cols])

categorical_cols = full_df.select_dtypes(include=['object']).columns
cat_imputer = SimpleImputer(strategy='most_frequent')
full_df[categorical_cols] = cat_imputer.fit_transform(full_df[categorical_cols])

label_encoders = {}
for col in categorical_cols:
    le = LabelEncoder()
    full_df[col] = le.fit_transform(full_df[col])
    label_encoders[col] = le

train_df = full_df.iloc[:len(train_df)]
test_df = full_df.iloc[len(train_df):]

X_train = train_df.drop('satisfaction', axis=1)
y_train = train_df['satisfaction']
X_test = test_df.drop('satisfaction', axis=1)
y_test = test_df['satisfaction']

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Majority-vote cluster accuracy 
def majority_vote_accuracy(model, X, y_true):
    cluster_labels = model.fit_predict(X)
    total_correct = 0

    for cluster_id in np.unique(cluster_labels):
        indices = np.where(cluster_labels == cluster_id)[0]
        cluster_true_labels = y_true.iloc[indices]
        if len(cluster_true_labels) == 0:
            continue
        majority_label_count = Counter(cluster_true_labels).most_common(1)[0][1]
        total_correct += majority_label_count

    return (total_correct / len(y_true)) * 100

# KMeans Clustering
print("Running KMeans...")
kmeans = KMeans(n_clusters=2, n_init=10, random_state=42)
kmeans_acc = majority_vote_accuracy(kmeans, X_train_scaled, y_train)

# MiniBatchKMeans Clustering
print("Running MiniBatchKMeans...")
mbk = MiniBatchKMeans(n_clusters=2, batch_size=1000, random_state=42)
mbk_acc = majority_vote_accuracy(mbk, X_train_scaled, y_train)

print(f"KMeans Accuracy: {kmeans_acc:.2f}%")
print(f"MiniBatchKMeans Accuracy: {mbk_acc:.2f}%")
